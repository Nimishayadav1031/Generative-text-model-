
import torch
import torch.nn as nn
import numpy as np
import random
import sys

# Sample dataset
corpus = """
Artificial Intelligence is the simulation of human intelligence processes by machines.
Machine learning is a subset of AI that allows systems to learn from data.
Deep learning is a subset of machine learning using neural networks with many layers.
"

# Preprocessing
chars = sorted(list(set(corpus)))
char_to_idx = {ch: i for i, ch in enumerate(chars)}
idx_to_char = {i: ch for i, ch in enumerate(chars)}

seq_length = 40
step = 3
sentences = []
next_chars = []

for i in range(0, len(corpus) - seq_length, step):
    sentences.append(corpus[i: i + seq_length])
    next_chars.append(corpus[i + seq_length])

# Vectorization
X = np.zeros((len(sentences), seq_length, len(chars)), dtype=np.float32)
y = np.zeros((len(sentences), len(chars)), dtype=np.float32)

for i, sentence in enumerate(sentences):
    for t, char in enumerate(sentence):
        X[i, t, char_to_idx[char]] = 1
    y[i, char_to_idx[next_chars[i]]] = 1

X_tensor = torch.tensor(X)
y_tensor = torch.tensor(y)

# LSTM Model
class TextGenerator(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(TextGenerator, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.fc(out[:, -1, :])
        return out

model = TextGenerator(len(chars), 128, len(chars))
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

# Training
epochs = 20
for epoch in range(epochs):
    model.train()
    optimizer.zero_grad()
    output = model(X_tensor)
    loss = criterion(output, y_tensor)
    loss.backward()
    optimizer.step()
    print(f"Epoch {epoch+1}/{epochs}, Loss: {loss.item():.4f}")

# Text generation
def generate_text(seed, length=200):
    model.eval()
    generated = seed
    sentence = seed

    for _ in range(length):
        x_pred = np.zeros((1, seq_length, len(chars)))
        for t, char in enumerate(sentence[-seq_length:]):
            if char in char_to_idx:
                x_pred[0, t, char_to_idx[char]] = 1
        x_tensor = torch.tensor(x_pred, dtype=torch.float32)
        preds = model(x_tensor).detach().numpy().squeeze()
        next_index = np.argmax(preds)
        next_char = idx_to_char[next_index]
        generated += next_char
        sentence += next_char
    return generated

# Example
seed_text = "Machine learning is a subset of AI tha"
print(generate_text(seed_text))
